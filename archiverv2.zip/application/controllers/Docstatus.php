<?php
defined('BASEPATH') or exit('No direct script access allowed');

require 'vendor/autoload.php';

class docstatus extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');
        $this->load->model('mod_docstatus');
        $this->load->model('mod_division');
        $this->load->model('mod_company');
    }

    public function index()
    {
        $data['content'] = "docstatus/index";
        $data['title'] = "STATUS DOKUMEN";
        $data['docstatus'] = $this->mod_docstatus->get_docstatus();
        $this->load->view('layout', $data);
    }

    public function form($id = null)
    {
        $data['docstatus'] = $this->mod_docstatus->get_docstatus($id)[0] ?? [];
        $data['divisions'] = $this->mod_division->get_division();
        $data['content'] = "docstatus/form";
        $data['title'] = "STATUS DOKUMEN";
        $this->load->view('layout', $data);
    }

    public function store()
    {
        $id = $this->input->post('id');
        $data = array(
            'code'              => strtoupper($_POST['code']),
            'name'              => $_POST['name'],
            "from_division_id"  => $_POST["from_division_id"],
            "to_division_id"    => $_POST["to_division_id"],
        );

        if ($id) {
            $this->mod_docstatus->set_docstatus($id, $data);
        } else {
            $this->mod_docstatus->add_docstatus($data);
        }

        return redirect('docstatus');
    }

    public function delete($id)
    {
        $this->mod_docstatus->remove_docstatus($id);
        return redirect('docstatus');
    }
}
