<?php
defined("BASEPATH") or exit("No direct script access allowed");

require "vendor/autoload.php";

use NcJoes\OfficeConverter\OfficeConverter;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\SimpleType\JcTable;
use PhpOffice\PhpWord\SimpleType\TblWidth;
use PhpOffice\PhpWord\TemplateProcessor;
use Dompdf\Dompdf;

class Document extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model("mod_user");
        $this->load->model("mod_document");
        $this->load->model("mod_company");
        $this->load->model("mod_division");
        $this->load->model("mod_doctype");
        $this->load->model("mod_docstatus");
        $this->load->model("mod_document_his");
        $this->load->model("mod_document_item");
        $this->load->model("mod_document_file");

        $this->load->library("pdf");
    }

    public function index($type)
    {
        $data["content"] = "document/index";
        $data["title"] = "DOKUMEN " . strtoupper($type);
        $data["documents"] = $this->mod_document->get_document("%", $type, $_SESSION['user']['division_id'], $_SESSION['company_id'] ?? "%");
        $data["type"] = $type;
        $this->load->view("layout", $data);
    }

    public function form($type, $id)
    {
        $data["content"] = "document/form";
        $data["title"] = "DOKUMEN " . strtoupper($type);
        $data["document"] = $this->mod_document->get_document($id, $type)[0] ?? [];
        $data["divisions"] = $this->mod_division->get_division();
        $data["doctypes"] = $this->mod_doctype->get_doctype();
        $data["docstatus"] = $this->mod_docstatus->get_docstatus('%', $_SESSION['user']['division_id'], '%' . $type . '%', '%' . $_SESSION['user']['role'] . '%');
        if ($type != "all") {
            $data["history"] = $this->mod_document_his->get_document_his($id ?? '') ?? [];
            $data["item"] = $this->mod_document_item->get_document_item($id, $type);
            array_push($data["item"], []);
            $data["dfile"] = $this->mod_document_file->get_document_file($id);
            array_push($data["dfile"], []);
        }

        if (
            isset($data["document"]["id"]) &&
            $data["document"]["from_division_id"] != $_SESSION['user']['division_id']
            && $data["document"]["to_division_id"] != $_SESSION['user']['division_id']
        ) {
            $this->session->set_flashdata("errmsg", "Anda tidak memiliki akses untuk mengakses dokumen ini.");
            return redirect("document/index/$type");
        }

        $data["type"] = $type;
        $this->load->view("layout", $data);
    }

    public function store($type)
    {
        $id = $_POST["id"];
        $data = array(
            "document_number"   => strtoupper($_POST["document_number"]),
            "subject"           => $_POST["subject"] ?? $this->mod_doctype->get_doctype($type)[0]["name"],
            "content"           => $_POST["content"] ?? $this->mod_doctype->get_doctype($type)[0]["name"],
            "doctype_id"        => $_POST["doctype_id"] ?? $this->mod_doctype->get_doctype($type)[0]["id"],
            "company_id"        => $_SESSION['company_id'],
            "from_division_id"  => $_POST["from_division_id"],
            "note"              => $_POST["note"],
            "user_create"       => $_POST["user_create"],
            "release_date"      => $_POST["release_date"],
            "create_date"       => $_POST["create_date"],
            "status"            => $_POST["status"],
        );
        $document_id = $this->do_store($id, "all", $data);
        if ($type != "all") {
            if ($type == "ca") {
                $data = array(
                    "document_id"        => $document_id,
                    "project"            => $_POST["project"],
                    "client"             => $_POST["client"],
                    "leave_date"         => $_POST["leave_date"],
                    "back_date"          => $_POST["back_date"],
                    "transfer_date"      => $_POST["transfer_date"],
                    "transfer_method"    => $_POST["transfer_method"],
                    "transfer_bank"      => $_POST["transfer_bank"],
                    "transfer_account"   => $_POST["transfer_account"],
                    "transfer_amount"    => str_replace(",", "", $_POST["transfer_amount"]),
                    "objective"          => $_POST["objective"]
                );
            } else if ($type == "pc") {
                $data = array(
                    "document_id"   => $document_id,
                    "project"       => $_POST["project"],
                    "customer"      => $_POST["customer"],
                    "bank"          => $_POST["bank"],
                    "account"       => $_POST["account"],
                    "account_name"  => $_POST["account_name"],
                );
            } else if ($type == "pp") {
                $data = array(
                    "document_id"           => $document_id,
                    "project"               => $_POST["project"],
                    "customer"              => $_POST["customer"],
                    "buy_date"              => $_POST["buy_date"],
                    "payment_max_date"      => $_POST["payment_max_date"],
                    "vendor"                => $_POST["vendor"],
                    "buy_type"              => $_POST["buy_type"],
                    "vendor_bank"           => $_POST["vendor_bank"],
                    "vendor_account"        => $_POST["vendor_account"],
                    "vendor_account_name"   => $_POST["vendor_account_name"]
                );
            }

            $this->do_store($id, $type, $data);
            $this->store_item($type, $data);
        }

        if ($_POST["document_number"] == null) {
            $data = array(
                "document_id"   => $document_id,
                "status"            => $_POST["status"]
            );
            $this->do_store($document_id, "all", $data);
        }

        return redirect("document/form/$type/$document_id");
    }

    public function store_file($data)
    {
        $this->mod_document_file->remove_document_file($data['document_id'] ?? '');
        for ($i = 0; $i < count($_POST['note_f']); $i++) {
            if ($_POST['note_f'][$i] != "") {
                $data = array(
                    'document_id'     => $data['document_id'],
                    'note'            => $_POST['note_f'][$i]
                );

                if (isset($_FILES["file_f"]["tmp_name"][$i])) {
                    move_uploaded_file($_FILES["file_f"]["tmp_name"][$i], "_shared/upload/" . $_FILES["file_f"]["name"][$i]);
                    $data['file_f']  = "_shared/upload/" . $_FILES["file_f"]["name"][$i];
                } else {
                    $data['file_f'] = $_POST['file_'][$i];
                }

                $this->mod_document_file->add_document_file($data);
            }
        }
    }

    public function store_item($type, $data)
    {
        if ($type != "all") {
            $this->mod_document_item->remove_document_item($data['document_id'] ?? '', $type);
            if ($type == "ca") {
                for ($i = 0; $i < count($_POST['description']); $i++) {
                    if ($_POST['description'][$i] != "") {
                        $data = array(
                            'document_id'     => $data['document_id'],
                            'description'     => $_POST['description'][$i],
                            'unit'            => $_POST['unit'][$i],
                            'price'           => str_replace(",", "", $_POST['price'][$i]),
                            'used'           => str_replace(",", "", $_POST['used'][$i])
                        );

                        if (isset($_FILES["file"]["tmp_name"][$i])) {
                            move_uploaded_file($_FILES["file"]["tmp_name"][$i], "_shared/upload/" . $_FILES["file"]["name"][$i]);
                            $data['file']  = "_shared/upload/" . $_FILES["file"]["name"][$i];
                        } else {
                            $data['file'] = $_POST['file_'][$i];
                        }

                        $this->mod_document_item->add_document_item($type, $data);
                    }
                }
            } else if ($type == "pc") {
                for ($i = 0; $i < count($_POST['description']); $i++) {
                    if ($_POST['description'][$i] != "") {
                        $data = array(
                            'document_id'     => $data['document_id'],
                            'description'     => $_POST['description'][$i],
                            'unit'            => $_POST['unit'][$i],
                            'price'           => str_replace(",", "", $_POST['price'][$i])
                        );

                        if (isset($_FILES["file"]["tmp_name"][$i])) {
                            move_uploaded_file($_FILES["file"]["tmp_name"][$i], "_shared/upload/" . $_FILES["file"]["name"][$i]);
                            $data['file']  = "_shared/upload/" . $_FILES["file"]["name"][$i];
                        } else {
                            $data['file'] = $_POST['file_'][$i];
                        }
                        $this->mod_document_item->add_document_item($type, $data);
                    }
                }
            } else if ($type == "pp") {
                for ($i = 0; $i < count($_POST['item']); $i++) {
                    if ($_POST['item'][$i] != "") {
                        $data = array(
                            'document_id'     => $data['document_id'],
                            'item'            => $_POST['item'][$i],
                            'unit'            => $_POST['unit'][$i],
                            'price'           => str_replace(",", "", $_POST['price'][$i]),
                        );
                        $this->mod_document_item->add_document_item($type, $data);
                    }
                }
            }
        }
    }

    public function do_store($id, $type, $data)
    {
        if ($type != "all") {
            $id = $this->mod_document->get_document($id, $type)[0]["id_2"] ?? "";
        }
        if ($id != "") {
            $this->mod_document->set_document($id, $type, $data);
        } else {
            if ($type == "all") {
                $company_code = $this->mod_company->get_company($data["company_id"] ?? "")[0]["code"] ?? "GTI";
                $division_code = $this->mod_division->get_division($data["from_division_id"] ?? "")[0]["code"] ?? "";
                $doctype_code = $this->mod_doctype->get_doctype($data["doctype_id"] ?? $type)[0]["code"];

                $document_number = $doctype_code . "/" . $division_code . "/" . $company_code . "/" . number_to_roman(date("m")) . "/" . date("Y");
                $document_number = $this->mod_document->get_document_number("%" . $document_number)[0]["last_document_number"] . "/" . $document_number;

                $data["document_number"]  = strtoupper($document_number);
            }
            $id = $this->mod_document->add_document($type, $data);
        }
        if ($type == "all") {
            $data = array(
                "document_id"     => $id,
                "update_date"     => date("Y-m-d H:i:s"),
                "user_update"     => $_SESSION['user']['fullname'],
                "status_update"   => $data["status"],
                "note"            => $_POST["note"],
            );
            $this->mod_document_his->add_document_his($data);
        }
        return $id;

        foreach ($this->mod_user->get_user($_POST["to_division_id"]) as $row) {
            $this->send_email($row["email"], $_POST["subject"], $_POST["content"]);
        }
    }

    public function cetak($type, $id)
    {
        $data = $this->mod_document->get_document($id, $type)[0];

        // if ($data["print"] == 2) {
        //     echo "Dokumen sudah pernah dicetak.";
        //     return;
        // }

        $data_ = array(
            "document_id"     => $id,
            "update_date"     => date("Y-m-d H:i:s"),
            "user_update"     => $_SESSION['user']['fullname'],
            "status_update"   => $data["status"],
            "note"            => "PRINT",
        );
        $this->mod_document_his->add_document_his($data_);
        $data_ = array(
            "print"          => $data["print"] + 1
        );
        $this->mod_document->set_document($id, "all", $data_);

        $template = "_shared/template/" . $type . ".docx";
        $filename = "_shared/surat/";
        $filename .= $data["doctype_name"] . "-" . $data["company_code"] . "-" . str_replace("/", "-", $data["document_number"]) . "-" . date("YmdHis");

        if ($type == "ca") {
            $data_ = array(
                "document_number" => $data["document_number"],
                "user_create" => $data["user_create"],
                "from_division" => $data["from_division"],
                "create_date" => custom_date_format($data["create_date"], 'd F Y'),
                "transfer_date" => custom_date_format($data["transfer_date"], 'd F Y'),
            );
            $data_["table_item"] = array();
            $data_["table_item"][] = array("No", "Keterangan Penggunaan", "Jumlah");
            $no = 1;
            $total = 0;
            foreach ($this->mod_document_item->get_document_item($id, $type) as $row) {
                $subtotal = (int) $row["unit"] * (int) $row["price"];
                $total += $subtotal;
                array_push($data_["table_item"], array(
                    $no++,
                    $row["description"] . " " . $row["unit"] . "x @" . number_format($row["price"]),
                    number_format($subtotal)
                ));
            }
            array_push($data_["table_item"], array("", "Total", number_format($total)));
            array_push($data_["table_item"], array("", "Jumlah yang diterima", number_format($data['transfer_amount'])));
        } else {
            $data_ = array(
                "document_number" => $data["document_number"],
                "subject" => $data["subject"],
                "user_create" => $data["user_create"],
                "from_division" => $data["from_division"],
                "to_division" => $data["to_division"],
                "content" => $data["content"],
                "release_date" => custom_date_format($data["release_date"], 'd F Y')
            );
        }

        $data_["print_date"] = custom_date_format(date("Y-m-d H:i:s"), 'd F Y H:i:s');

        $this->edit_word($template, $data_, $filename . ".docx");
        $this->word_to_pdf($filename);
    }

    public function delete($type, $id)
    {
        if ($type != "all") {
            $id = $this->mod_document->get_document($id, $type)[0]["id_2"] ?? "";
        }
        $this->mod_document->remove_document($id, $type);
        return redirect("document/index/$type");
    }

    function edit_word($template, $data, $filename)
    {
        $phpWord = new PhpWord();
        $templateProcessor = new TemplateProcessor($template);
        $jctable = new JcTable();
        $tableStyle = new TblWidth();

        $tableStyleArray = [
            'borderSize' => 10,
            'borderColor' => '999999',
            'alignment' => $jctable::CENTER,
            'unit' => $tableStyle::PERCENT,
            'width' => 100 * 50,
        ];

        $trStyle = ['align' => 'center'];
        $thStyle = ['size' => 11, 'bold' => true];
        $tdStyle = ['size' => 11];

        foreach ($data as $key => $value) {
            if (str_contains($key, 'table')) {
                $section = $phpWord->addSection();
                $table = $section->addTable($tableStyleArray);

                $tno = 0;
                foreach ($value as $tr) {
                    $table->addRow();
                    foreach ($tr as $td) {
                        $table->addCell(1, $trStyle)->addText($td, $tno == 0 ? $thStyle : $tdStyle);
                    }
                    $tno++;
                }

                $templateProcessor->setComplexBlock($key, $table);
            } else {
                $templateProcessor->setValue($key, htmlspecialchars($value));
            }
        }

        $templateProcessor->saveAs($filename);
    }

    function word_to_pdf($filename)
    {
        // $phpWord = IOFactory::load($filename . ".docx");
        // $htmlWriter = IOFactory::createWriter($phpWord, 'HTML');
        // $htmlWriter->save($filename . ".html");

        // $dompdf = new Dompdf();
        // $dompdf->loadHtml(file_get_contents($filename . ".docx"));
        // $dompdf->setPaper('A4', 'portrait');
        // $dompdf->render();
        // file_put_contents($filename . ".pdf", $dompdf->output());

        return redirect($filename . ".docx");
    }

    function send_email($to, $subject, $body)
    {
        $mail = new PHPMailer(true);
        try {
            $mail->IsSMTP();
            $mail->CharSet = "UTF-8";

            $mail->Host       = "mawarserver.ardetamedia.net";
            $mail->SMTPDebug  = 0;
            $mail->SMTPAuth   = true;
            $mail->Port       = 587;
            $mail->Username   = "yohanes.randy@corsys.co.id";
            $mail->Password   = "Kurnianto72639!!!";
            $mail->setFrom("yohanes.randy@corsys.co.id");

            $mail->addAddress($to);
            $mail->isHTML(false);
            $mail->Subject = $subject;
            $mail->Body    = $body;
            // $mail->AltBody = $body;

            $mail->send();
        } catch (Exception $e) {
            $this->session->set_flashdata("errmsg", "Email gagal dikirim. Pesan error: $mail->ErrorInfo | " . $e->getMessage());
        }
    }
}
