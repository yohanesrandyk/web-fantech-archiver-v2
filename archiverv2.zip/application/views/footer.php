<div class="footer bg-white py-4 d-flex flex-lg-column" id="kt_footer">
    <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
        <div class="text-dark order-2 order-md-1">
            <span class="text-dark font-weight-bold mr-2">2023©</span>
            <a href="https://www.corsys.co.id" target="_blank" class="text-dark-75 text-hover-danger font-weight-bold">yohanesrandy</a>
        </div>
    </div>
</div>